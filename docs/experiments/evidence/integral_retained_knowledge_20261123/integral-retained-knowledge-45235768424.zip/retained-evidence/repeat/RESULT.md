# Integral causal revision trial

**Verdict: FAIL**

Complete evidence chain: **0/8** worlds.

| Phase | Goals | Episodes | Rate | Actions | Useful sensor | Noise sensor |
|---|---:|---:|---:|---:|---:|---:|
| acquire | 1160 | 2048 | 56.6% | 5028 | 2083 | 936 |
| original_held | 447 | 512 | 87.3% | 1247 | 607 | 128 |
| adaptive | 3687 | 4096 | 90.0% | 10895 | 4904 | 1922 |
| frozen | 538 | 4096 | 13.1% | 9997 | 4877 | 1024 |
| recovered_held | 512 | 512 | 100.0% | 1380 | 637 | 231 |
| shuffled_cue_held | 270 | 512 | 52.7% | 1385 | 641 | 232 |
| stale_held | 64 | 512 | 12.5% | 1248 | 608 | 128 |
| random_held | 240 | 512 | 46.9% | 937 | 227 | 219 |

## Frozen checks

- PASS: all_eight_worlds_valid
- PASS: acquisition_at_least_80_percent
- PASS: recovery_at_least_80_percent
- FAIL: complete_loop_in_at_least_six_worlds
- PASS: recovery_exceeds_frozen_by_20_points
- PASS: recovery_exceeds_shuffled_cue_by_20_points
- PASS: recovery_exceeds_random_by_20_points

## Per-world evidence

| World | Original | Recovered | Contradiction | New sensing | Corrected forecast | Full chain |
|---|---:|---:|---|---|---|---|
| 0 | 100.0% | 100.0% | True | True | False | False |
| 1 | 100.0% | 100.0% | True | True | False | False |
| 2 | 100.0% | 100.0% | True | True | False | False |
| 3 | 100.0% | 100.0% | True | True | False | False |
| 4 | 100.0% | 100.0% | True | True | False | False |
| 5 | 46.9% | 100.0% | True | True | False | False |
| 6 | 51.6% | 100.0% | True | True | False | False |
| 7 | 100.0% | 100.0% | True | True | False | False |

This is an unchanged-production test of one synthetic family. A successful build is not a capability PASS.
Full prospective action/outcome forecasts and factual trajectories are in the accompanying JSONL files.
