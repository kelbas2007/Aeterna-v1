# Integral retained-knowledge continuation

**Continuation verdict: FAIL**

The original result remains **FAIL, 4/8 complete chains**. Historical replay is state reconstruction, not fresh qualification.

Original world seed: `45231338992`. Current run ID `45235768424` is provenance only.
Global replay barrier: **PASS**.
Retained state continuity: **PASS**.

Strict repeat verdict under unchanged thresholds: **FAIL**, complete chains **0/8**, required **6/8**.

## Cold and retained-state results

| Phase | Cold goals | Repeat goals | Change, percentage points | Cold actions | Repeat actions |
|---|---:|---:|---:|---:|---:|
| acquire | 1557/2048 | 1160/2048 | -19.38 | 3583 | 5028 |
| original_held | 504/512 | 447/512 | -11.13 | 1069 | 1247 |
| adaptive | 3419/4096 | 3687/4096 | +6.54 | 10902 | 10895 |
| frozen | 56/4096 | 538/4096 | +11.77 | 8549 | 9997 |
| recovered_held | 512/512 | 512/512 | +0.00 | 1347 | 1380 |
| shuffled_cue_held | 270/512 | 270/512 | +0.00 | 1347 | 1385 |
| stale_held | 10/512 | 64/512 | +10.55 | 1079 | 1248 |
| random_held | 240/512 | 240/512 | +0.00 | 937 | 937 |

## Per-world gates

| World | Cold full chain | Repeat full chain | Failed repeat stages |
|---|---|---|---|
| 0 | False | False | same_context_prediction_corrected |
| 1 | False | False | same_context_prediction_corrected |
| 2 | True | False | same_context_prediction_corrected |
| 3 | True | False | same_context_prediction_corrected |
| 4 | False | False | same_context_prediction_corrected |
| 5 | False | False | acquired, same_context_prediction_corrected |
| 6 | True | False | acquired, same_context_prediction_corrected |
| 7 | True | False | same_context_prediction_corrected |

## Retained starting state

| World | Factual events retained | Learned transitions retained | Input checkpoint SHA256 |
|---|---:|---:|---|
| 0 | 1543 | 1543 | e857adafad7f98380caeda9d983fa1e6e5010b63779834685470e944941fc923 |
| 1 | 1963 | 1963 | d8e9c715640e60d3f7bea64ff231a2864b2a381a63243895d7fe2b28ce09734d |
| 2 | 1724 | 1724 | 3b40c4beface108809162f751096b46a115c0cb167b82e651d57b305b022e094 |
| 3 | 1621 | 1621 | 39607f695f01a4032379a088f37c57a332e487991969a1f54a65bf17560d74a2 |
| 4 | 1989 | 1989 | c247a9f06e34eef57d9af3c2225813e0f296149c6cb7f0e208ecfa64ae7e9486 |
| 5 | 1623 | 1623 | 750bed56b0a21d7c04711778566ecf93f67782a44adec68e3641c409c4462a0b |
| 6 | 2088 | 2088 | 4ce28bd10bd0835438aa39eb4732d6c0bf785f411bdb64884d0f6f1bdd95ea7e |
| 7 | 1934 | 1934 | eacadf1c6fc6113b206c607ab65c6d020b323e2f237c370b7f6bcdaa22c3cb29 |

## Interpretation

- The first FAIL and its 4/8 complete chains remain unchanged.
- All eight historical traces and parsed summaries must match before any repeat actor starts.
- Reconstruction restores a historical state; it is not a new successful trial.
- The repeat preserves motor/symbol meanings, the original episode schedule and all capability thresholds.
- The retained endpoint knows rule 1; returning to rule 0 is itself an unannounced change.
- Retained state includes RNG/counters/model/policy; this does not isolate causal memory alone.
- No fresh schedule or unrelated-task transfer is measured.
- Goal improvement and stricter forecast correction are reported separately.

`continuation.json` contains complete comparisons, costs, source/binary/checkpoint hashes and per-world integrity details.
`repeat/verdict.json` is produced by the unchanged original scorer. All traces, checkpoints, failures and timeouts are retained.
