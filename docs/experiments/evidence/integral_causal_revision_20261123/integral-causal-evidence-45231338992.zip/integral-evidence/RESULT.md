# Integral causal revision trial

**Verdict: FAIL**

Complete evidence chain: **4/8** worlds.

| Phase | Goals | Episodes | Rate | Actions | Useful sensor | Noise sensor |
|---|---:|---:|---:|---:|---:|---:|
| acquire | 1557 | 2048 | 76.0% | 3583 | 1177 | 373 |
| original_held | 504 | 512 | 98.4% | 1069 | 512 | 45 |
| adaptive | 3419 | 4096 | 83.5% | 10902 | 4842 | 2007 |
| frozen | 56 | 4096 | 1.4% | 8549 | 4096 | 357 |
| recovered_held | 512 | 512 | 100.0% | 1347 | 674 | 161 |
| shuffled_cue_held | 270 | 512 | 52.7% | 1347 | 674 | 161 |
| stale_held | 10 | 512 | 2.0% | 1079 | 512 | 55 |
| random_held | 240 | 512 | 46.9% | 937 | 227 | 219 |

## Frozen checks

- PASS: all_eight_worlds_valid
- PASS: acquisition_at_least_80_percent
- PASS: recovery_at_least_80_percent
- FAIL: complete_loop_in_at_least_six_worlds
- PASS: recovery_exceeds_frozen_by_20_points
- PASS: recovery_exceeds_shuffled_cue_by_20_points
- PASS: recovery_exceeds_random_by_20_points

## Per-world evidence

| World | Original | Recovered | Contradiction | New sensing | Corrected forecast | Full chain |
|---|---:|---:|---|---|---|---|
| 0 | 100.0% | 100.0% | True | True | False | False |
| 1 | 100.0% | 100.0% | True | True | False | False |
| 2 | 100.0% | 100.0% | True | True | True | True |
| 3 | 100.0% | 100.0% | True | True | True | True |
| 4 | 100.0% | 100.0% | True | True | False | False |
| 5 | 87.5% | 100.0% | True | True | False | False |
| 6 | 100.0% | 100.0% | True | True | True | True |
| 7 | 100.0% | 100.0% | True | True | True | True |

This is an unchanged-production test of one synthetic family. A successful build is not a capability PASS.
Full prospective action/outcome forecasts and factual trajectories are in the accompanying JSONL files.
